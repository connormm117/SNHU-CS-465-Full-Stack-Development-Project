// seedTrips.js
require('./app_api/models/db'); // sets up mongoose connection and loads the Trip model

const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

// 👉 Hard-coded sample trips that match the schema exactly
const tripsData = [
  {
    code: 'TR001',
    name: 'Island Adventure',
    length: 7,
    start: new Date('2026-01-15'),
    resort: 'Blue Lagoon Resort',
    perPerson: 1899,
    image: 'island-adventure.jpg',
    description: 'Enjoy 7 days of sunshine, crystal-clear water, and daily excursions on this all-inclusive island getaway.'
  },
  {
    code: 'TR002',
    name: 'Mountain Escape',
    length: 5,
    start: new Date('2026-02-10'),
    resort: 'Summit View Lodge',
    perPerson: 1299,
    image: 'mountain-escape.jpg',
    description: 'Experience breathtaking views, guided hikes, and cozy evenings by the fire on this mountain retreat.'
  },
  {
    code: 'TR003',
    name: 'City Lights Tour',
    length: 3,
    start: new Date('2026-03-05'),
    resort: 'Urban Oasis Hotel',
    perPerson: 899,
    image: 'city-lights.jpg',
    description: 'Discover nightlife, fine dining, and cultural landmarks on this exciting city escape.'
  }
];

const seed = async () => {
  try {
    console.log('Clearing existing trips...');
    await Trip.deleteMany({});

    console.log('Inserting sample trips...');
    await Trip.insertMany(tripsData);

    console.log('✅ Trips collection has been populated.');
  } catch (err) {
    console.error('Error seeding trips:', err);
  } finally {
    await mongoose.connection.close();
    console.log('Mongoose connection closed.');
  }
};

seed().catch(err => {
  console.error('Unexpected error in seed script:', err);
});
