const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const User = mongoose.model('User');

// In a real app use a strong secret from env vars
const JWT_SECRET = process.env.JWT_SECRET || 'changeme_in_production';
const JWT_EXPIRES_IN = '1h';

// Helper to create token payload
function generateToken(user) {
  return jwt.sign(
    {
      _id: user._id,
      username: user.username,
      name: user.name
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

// POST /api/register  (for testing with mock data in Postman)
module.exports.register = async function (req, res) {
  try {
    const { username, password, name } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required.' });
    }

    const existing = await User.findOne({ username: username.toLowerCase() }).exec();
    if (existing) {
      return res.status(409).json({ message: 'User already exists.' });
    }

    const user = new User({ username: username.toLowerCase(), name });
    await user.setPassword(password);
    await user.save();

    const token = generateToken(user);
    res.status(201).json({ token });
  } catch (err) {
    console.error('Register error', err);
    res.status(500).json({ message: 'Error registering user.' });
  }
};

// POST /api/login
module.exports.login = async function (req, res) {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required.' });
    }

    const user = await User.findOne({ username: username.toLowerCase() }).exec();
    if (!user) {
      return res.status(401).json({ message: 'Invalid username or password.' });
    }

    const isValid = await user.validPassword(password);
    if (!isValid) {
      return res.status(401).json({ message: 'Invalid username or password.' });
    }

    const token = generateToken(user);
    res.status(200).json({ token });
  } catch (err) {
    console.error('Login error', err);
    res.status(500).json({ message: 'Error logging in.' });
  }
};
