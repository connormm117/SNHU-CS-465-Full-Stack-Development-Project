const mongoose = require('mongoose');

// Try to get the model with either name ("Trip" or "trips"),
// depending on how it was registered in app_api/models/travlr.js
let Trip;
try {
  Trip = mongoose.model('Trip');
} catch (e) {
  Trip = mongoose.model('trips');
}

// GET /api/trips  → list all trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().exec();
    res.status(200).json(trips);
  } catch (err) {
    res.status(500).json(err);
  }
};

// GET /api/trips/:tripCode  → get one trip by code
const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    res.status(200).json(trip);
  } catch (err) {
    res.status(500).json(err);
  }
};

// POST /api/trips  → add a new trip
const tripsAddOne = async (req, res) => {
  try {
    const newTrip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });
    res.status(201).json(newTrip);
  } catch (err) {
    res.status(400).json(err);
  }
};

// PUT /api/trips/:tripCode  → update an existing trip
const tripsUpdateOne = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }

    trip.name = req.body.name;
    trip.length = req.body.length;
    trip.start = req.body.start;
    trip.resort = req.body.resort;
    trip.perPerson = req.body.perPerson;
    trip.image = req.body.image;
    trip.description = req.body.description;

    const updated = await trip.save();
    res.status(200).json(updated);
  } catch (err) {
    res.status(400).json(err);
  }
};

// DELETE /api/trips/:tripCode  → delete a trip
const tripsDeleteOne = async (req, res) => {
  try {
    const deleted = await Trip.findOneAndDelete({ code: req.params.tripCode }).exec();
    if (!deleted) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    res.status(204).json(null);
  } catch (err) {
    res.status(500).json(err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddOne,
  tripsUpdateOne,
  tripsDeleteOne
};
