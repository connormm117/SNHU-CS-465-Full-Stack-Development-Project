const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET || 'changeme_in_production';

// Verify token from Authorization: Bearer <token>
module.exports.requireAuth = function (req, res, next) {
  const authHeader = req.headers['authorization'] || '';
  const parts = authHeader.split(' ');

  if (parts.length !== 2 || parts[0] !== 'Bearer') {
    return res.status(401).json({ message: 'Authorization header missing or malformed.' });
  }

  const token = parts[1];

  jwt.verify(token, JWT_SECRET, function (err, payload) {
    if (err) {
      console.error('JWT verify error', err);
      return res.status(401).json({ message: 'Invalid or expired token.' });
    }

    // If valid, add the payload to the request object
    req.user = payload;
    next();
  });
};
