const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');
const { requireAuth } = require('../middleware/auth');

// /api/trips  → list trips (public), add trip (admin only)
router
  .route('/trips')
  .get(ctrlTrips.tripsList)                    // public: customers see trips
  .post(requireAuth, ctrlTrips.tripsAddOne);   // protected: admin only

// /api/trips/:tripCode → get one (public), update/delete (admin only)
router
  .route('/trips/:tripCode')
  .get(ctrlTrips.tripsFindByCode)                  // public
  .put(requireAuth, ctrlTrips.tripsUpdateOne)      // protected
  .delete(requireAuth, ctrlTrips.tripsDeleteOne);  // protected

// Authentication
// Use /api/register in Postman ONCE to create an admin user
router.post('/register', ctrlAuth.register);

// SPA and Postman will use /api/login to get a JWT token
router.post('/login', ctrlAuth.login);

module.exports = router;
