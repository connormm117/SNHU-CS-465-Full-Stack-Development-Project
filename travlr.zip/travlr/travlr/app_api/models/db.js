const mongoose = require('mongoose');

const dbURI = 'mongodb://127.0.0.1:27017/travlr';

mongoose.connect(dbURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

mongoose.connection.on('connected', () => {
  console.log('Mongoose connected to ' + dbURI);
});

mongoose.connection.on('error', err => {
  console.log('Mongoose connection error: ' + err);
});

mongoose.connection.on('disconnected', () => {
  console.log('Mongoose disconnected');
});

// For nodemon restarts (SIGUSR2)
process.once('SIGUSR2', () => {
  mongoose.connection.close()
    .then(() => {
      console.log('Mongoose disconnected through app termination (SIGUSR2)');
      process.kill(process.pid, 'SIGUSR2');
    })
    .catch(err => {
      console.error('Error during Mongoose disconnect (SIGUSR2):', err);
      process.kill(process.pid, 'SIGUSR2');
    });
});

// For app termination (Ctrl+C)
process.on('SIGINT', () => {
  mongoose.connection.close()
    .then(() => {
      console.log('Mongoose disconnected through app termination (SIGINT)');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error during Mongoose disconnect (SIGINT):', err);
      process.exit(1);
    });
});

// For Heroku / OS shutdown (SIGTERM)
process.on('SIGTERM', () => {
  mongoose.connection.close()
    .then(() => {
      console.log('Mongoose disconnected through app termination (SIGTERM)');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error during Mongoose disconnect (SIGTERM):', err);
      process.exit(1);
    });
});

// Load models
require('./travlr');
require('./user'); 