const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  name: {
    type: String
  },
  hash: {
    type: String,
    required: true
  }
});

// Set a hashed password
userSchema.methods.setPassword = async function (password) {
  const salt = await bcrypt.genSalt(10);
  this.hash = await bcrypt.hash(password, salt);
};

// Validate password
userSchema.methods.validPassword = async function (password) {
  return bcrypt.compare(password, this.hash);
};

mongoose.model('User', userSchema);
