import { Routes } from '@angular/router';
import { TripListComponent } from './trips/trip-list/trip-list';
import { TripAddComponent } from './trips/trip-add/trip-add';
import { TripEditComponent } from './trips/trip-edit/trip-edit';

export const routes: Routes = [
  { path: '', component: TripListComponent },
  { path: 'add', component: TripAddComponent },
  { path: 'edit/:code', component: TripEditComponent }
];
