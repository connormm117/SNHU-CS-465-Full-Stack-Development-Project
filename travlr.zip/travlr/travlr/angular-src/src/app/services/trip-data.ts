import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';   // <-- FIXED PATH

@Injectable({
  providedIn: 'root'
})
export class TripDataService {

  private apiUrl = 'http://localhost:3000/api/trips';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  // GET all trips
  getTrips(): Observable<any> {
    return this.http.get(this.apiUrl);
  }

  // GET one trip
  getTrip(code: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${code}`);
  }

  // used by trip-edit
  getTripByCode(code: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${code}`);
  }

  // helper: builds Authorization header
  private authHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders(
      token
        ? { Authorization: `Bearer ${token}` }
        : {}
    );
  }

  // POST create new trip (protected)
  addTrip(trip: any): Observable<any> {
    return this.http.post(this.apiUrl, trip, { headers: this.authHeaders() });
  }

  // PUT update trip (protected)
  updateTrip(code: string, trip: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${code}`, trip, { headers: this.authHeaders() });
  }

  // DELETE trip (protected)
  deleteTrip(code: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${code}`, { headers: this.authHeaders() });
  }
}


