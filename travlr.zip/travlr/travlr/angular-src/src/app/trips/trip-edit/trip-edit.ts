import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDataService } from '../../services/trip-data';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-trip-edit',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-edit.html',
  styleUrls: ['./trip-edit.css']
})
export class TripEditComponent implements OnInit {

  trip: any = {};

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripService: TripDataService
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');
    if (tripCode) {
      this.tripService.getTripByCode(tripCode).subscribe((t: any) => {
        this.trip = t;
      });
    }
  }

  saveTrip(): void {
    const tripCode = this.trip.code;
    this.tripService.updateTrip(tripCode, this.trip).subscribe(() => {
      this.router.navigate(['/admin/trips']);  // adjust route if yours is different
    });
  }
}

