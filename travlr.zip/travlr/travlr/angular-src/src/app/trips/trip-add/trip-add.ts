import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TripDataService } from '../../services/trip-data';

@Component({
  selector: 'app-trip-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-add.html',
  styleUrl: './trip-add.css'
})
export class TripAddComponent {

  trip: any = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(private tripService: TripDataService,
              private router: Router) {}

  addTrip(): void {
    this.tripService.addTrip(this.trip).subscribe({
      next: () => this.router.navigate(['/']),
      error: err => console.error(err)
    });
  }
}

