const express = require('express');
const path = require('path');
const router = express.Router();

// Load trip data
const trips = require(path.join(__dirname, '..', 'data', 'trips.json'));

// Home
router.get('/', (req, res) => {
  res.render('index', {
    title: 'Travlr Getaways',
    tagline: 'Hand-picked adventures rendered with HBS'
  });
});

// Travel listing
router.get('/travel', (req, res) => {
  res.render('travel', {
    title: 'Travel',
    trips
  });
});

module.exports = router;
