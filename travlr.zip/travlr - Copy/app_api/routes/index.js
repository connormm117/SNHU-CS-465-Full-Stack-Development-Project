const express = require('express');
const router = express.Router();

const ctrlTrips = require('../controllers/trips');

// /api/trips  → list trips, add trip
router
  .route('/trips')
  .get(ctrlTrips.tripsList)
  .post(ctrlTrips.tripsAddOne);

// /api/trips/:tripCode → get one, update, delete
router
  .route('/trips/:tripCode')
  .get(ctrlTrips.tripsFindByCode)
  .put(ctrlTrips.tripsUpdateOne)
  .delete(ctrlTrips.tripsDeleteOne);

module.exports = router;

