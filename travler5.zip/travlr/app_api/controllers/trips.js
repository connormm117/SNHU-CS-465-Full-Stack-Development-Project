const mongoose = require('mongoose');
const Trip = mongoose.model('Trip');

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find().exec();
    res.status(200).json(trips);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error getting trips', error: err });
  }
};

const tripFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({ code: req.params.tripCode }).exec();
    if (!trip) {
      return res.status(404).json({ message: 'Trip not found' });
    }
    res.status(200).json(trip);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error getting trip', error: err });
  }
};

module.exports = {
  tripsList,
  tripFindByCode
};
